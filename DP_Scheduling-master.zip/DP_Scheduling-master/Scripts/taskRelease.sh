./liblitmus/release_ts
cat /proc/litmus/stats

