./liblitmus/setsched P-FP
./liblitmus/rtspin -w -q 4 25 70 10 &
./liblitmus/rtspin -w -q 5 35 80 10 &
./liblitmus/rtspin -w -q 6 20 120 10 &
#./liblitmus/rtspin -w -q 6 1 6 1:0 &
