/* Fixed-priority scheduler support.
 */

#ifndef __FP_COMMON_H__
#define __FP_COMMON_H__

#include <litmus/rt_domain.h>

#include <asm/bitops.h>





void fp_domain_init(rt_domain_t* rt, check_resched_needed_t resched,
		    release_jobs_t release);

int fp_higher_prio(struct task_struct* first,
		   struct task_struct* second);

int fp_ready_order(struct bheap_node* a, struct bheap_node* b);

#define FP_PRIO_BIT_WORDS (LITMUS_MAX_PRIORITY / BITS_PER_LONG)

#if (LITMUS_MAX_PRIORITY % BITS_PER_LONG)
#error LITMUS_MAX_PRIORITY must be a multiple of BITS_PER_LONG
#endif


/* bitmask-inexed priority queue */
struct fp_prio_queue {
	unsigned long	bitmask[FP_PRIO_BIT_WORDS];
	struct bheap	queue[LITMUS_MAX_PRIORITY];
};

//////////////////
/*   Dual Priority   */


struct dp_list {
	int dp_pid;
	lt_t tsk_C;
	lt_t tsk_D;
	int pfp_priority;
	int dp_priority;
	lt_t dp_PrPoint;
	int dp_timerStatus;
	lt_t dp_time_to_fired;
	
	struct list_head dp_data_list;
};



void add_dp_node(int PID, lt_t tsk_C, lt_t tsk_D, int pfp_priority, int dp_priority, lt_t dp_PrPoint, int tmrStatus, lt_t dp_time_to_fired);
void dp_display(void);

int dp_Size(void);
void dp_delete_all(void);
int dp_find_first_and_delete(int PID);
int dp_get_Pri1(int PID);
int dp_get_Pri2(int PID);
lt_t dp_get_PrPoint(int PID);
void dp_set_Pri2(int PID, int Pri2);
void dp_set_PrPoint(int PID, lt_t PrPoint);
int dp_Find_PID(int PID);
void calculate_Pri2_RM(void);
void calculate_ProPoint(void);
int dp_get_tmrStatus(int PID);
void dp_set_tmrStatus(int PID, int tmrStatus);




int dp_get_PID_from_fireTask(void);
int dp_is_TimerARM(void);
int dp_get_Armed_PID(void);



lt_t dp_get_time_to_Fire(int PID);
void dp_set_time_Released(int PID, lt_t time_to_Fire_Value);

int dp_get_PID_earliest_trigger_time(void);






//struct list_head* get_dp_linkhead(void);





/*   Dual Priority   */
//////////////////




void fp_prio_queue_init(struct fp_prio_queue* q);

static inline void fpq_set(struct fp_prio_queue* q, unsigned int index)
{
	unsigned long *word = q->bitmask + (index / BITS_PER_LONG);
	__set_bit(index % BITS_PER_LONG, word);
}

static inline void fpq_clear(struct fp_prio_queue* q, unsigned int index)
{
	unsigned long *word = q->bitmask + (index / BITS_PER_LONG);
	__clear_bit(index % BITS_PER_LONG, word);
}

static inline unsigned int fpq_find(struct fp_prio_queue* q)
{
	int i;

	/* loop optimizer should unroll this */
	for (i = 0; i < FP_PRIO_BIT_WORDS; i++)
		if (q->bitmask[i])
			return __ffs(q->bitmask[i]) + i * BITS_PER_LONG;

	return LITMUS_MAX_PRIORITY; /* nothing found */
}

static inline void fp_prio_add(struct fp_prio_queue* q, struct task_struct* t, unsigned int index)
{
	BUG_ON(index >= LITMUS_MAX_PRIORITY);
	BUG_ON(bheap_node_in_heap(tsk_rt(t)->heap_node));

	fpq_set(q, index);
	bheap_insert(fp_ready_order, &q->queue[index], tsk_rt(t)->heap_node);
}

static inline void fp_prio_remove(struct fp_prio_queue* q, struct task_struct* t, unsigned int index)
{
	BUG_ON(!is_queued(t));

	bheap_delete(fp_ready_order, &q->queue[index], tsk_rt(t)->heap_node);
	if (likely(bheap_empty(&q->queue[index])))
		fpq_clear(q, index);
}

static inline struct task_struct* fp_prio_peek(struct fp_prio_queue* q)
{
	unsigned int idx = fpq_find(q);
	struct bheap_node* hn;

	if (idx < LITMUS_MAX_PRIORITY) {
		hn = bheap_peek(fp_ready_order, &q->queue[idx]);
		return bheap2task(hn);
	} else
		return NULL;
}

static inline struct task_struct* fp_prio_take(struct fp_prio_queue* q)
{
	unsigned int idx = fpq_find(q);
	struct bheap_node* hn;

	if (idx < LITMUS_MAX_PRIORITY) {
		hn = bheap_take(fp_ready_order, &q->queue[idx]);
		if (likely(bheap_empty(&q->queue[idx])))
			fpq_clear(q, idx);
		return bheap2task(hn);
	} else
		return NULL;
}

int fp_preemption_needed(struct fp_prio_queue*  q, struct task_struct *t);


#endif
